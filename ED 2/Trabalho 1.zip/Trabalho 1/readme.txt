## Integrantes ##

    Igor Zago Massaro - 217999
    Victor Pereira - 206538     

## Tema ##
    
    Jogadores de futebol

## Exemplo de Interação ##

    Nome: Igor
    Idade: 21
    Altura: 1.68
    Time: Barcelona 
    Opcao: (1: adicionar gols marcados, 2:adicionar total de partidas) 1
    Gols marcados: 23

    Jogador 1
    Nome: Igor
    Time: Barcelona
    Gols: 23